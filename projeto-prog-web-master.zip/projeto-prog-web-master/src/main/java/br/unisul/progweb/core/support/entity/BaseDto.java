package br.unisul.progweb.core.support.entity;

import java.io.Serializable;

public abstract class BaseDto implements Serializable {
    private static final long serialVersionUID = 1L;

}
