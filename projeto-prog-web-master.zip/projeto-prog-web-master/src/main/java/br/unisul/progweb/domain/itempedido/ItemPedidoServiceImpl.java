package br.unisul.progweb.domain.itempedido;

import br.unisul.progweb.core.support.service.AbstractService;
import org.springframework.stereotype.Service;

@Service
public class ItemPedidoServiceImpl extends AbstractService<ItemPedido, Long, ItemPedidoRepository> implements ItemPedidoService{
}
