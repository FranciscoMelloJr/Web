package br.unisul.progweb.domain.itempedido;

import br.unisul.progweb.core.support.service.BaseService;

public interface ItemPedidoService extends BaseService<ItemPedido, Long> {
}
