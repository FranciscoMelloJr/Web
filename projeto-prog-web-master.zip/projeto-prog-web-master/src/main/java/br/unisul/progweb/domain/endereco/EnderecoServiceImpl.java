package br.unisul.progweb.domain.endereco;

import br.unisul.progweb.core.support.service.AbstractService;
import org.springframework.stereotype.Service;

@Service
public class EnderecoServiceImpl extends AbstractService<Endereco, Long, EnderecoRepository> implements EnderecoService {
}
