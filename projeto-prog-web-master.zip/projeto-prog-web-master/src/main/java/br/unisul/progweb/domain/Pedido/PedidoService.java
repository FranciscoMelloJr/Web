package br.unisul.progweb.domain.Pedido;

import br.unisul.progweb.core.support.service.BaseService;

public interface PedidoService extends BaseService<Pedido, Long> {
}
