package br.unisul.progweb.domain.estado;

import br.unisul.progweb.core.support.service.BaseService;

public interface EstadoService extends BaseService<Estado, Long> {

}
