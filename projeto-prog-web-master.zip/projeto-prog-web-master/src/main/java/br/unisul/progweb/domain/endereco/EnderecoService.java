package br.unisul.progweb.domain.endereco;

import br.unisul.progweb.core.support.service.BaseService;

public interface EnderecoService extends BaseService<Endereco, Long> {
}
